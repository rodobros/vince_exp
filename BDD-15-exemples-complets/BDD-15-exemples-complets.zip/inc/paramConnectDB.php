<?php
define("HOST",     "localhost");
define("USER",     "root");
define("PASSWORD", "");
define("DBNAME",   "club_video");